import React from "react";

const BrandIndia = () => {
  return (
    <div className="bg-red-500 text-white text-center font-bold py-2 sm:py-3 rounded-md my-2 sm:my-4 text-sm sm:text-xl md:text-xl">
      BRAND OF INDIA
    </div>
  );
};

export default BrandIndia;
